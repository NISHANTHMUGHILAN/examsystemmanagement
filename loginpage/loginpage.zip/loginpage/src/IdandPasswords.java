import java.util.HashMap;

public class IdandPasswords {
    HashMap<String,String> logininfo=new HashMap<String,String>();
    IdandPasswords(){
        logininfo.put("Admin","123");
    }
    protected HashMap getLoginInfo(){
        return logininfo;
    }
}

